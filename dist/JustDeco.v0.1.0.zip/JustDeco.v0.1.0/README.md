# JustDeco
 A simple mod for 7 days to die: Just deco!

# Included recipes

**Outdoor furniture**

- 8 ember piles. They are from vanilla game. They are from vanilla game, fixed the economic value to something useful.
 
![image](https://github.com/user-attachments/assets/abfd144b-0e8d-4cee-b4c3-8ec97dc39381)
 
- 22 table umbrellas (11 colours and two variants, up and down umbrella). They are from vanilla game.
 
![image](https://github.com/user-attachments/assets/0104387b-c0f0-4016-bd46-3c889bc016f6)

- 10 camping chairs (10 colours). They are from vanilla game, fixed the economic value to something useful.

![image](https://github.com/user-attachments/assets/1a4f06f5-adff-4ce1-b140-b59904b3e95d)

- 2 park benches. They are from vanilla game, fixed the economic value to something useful.

![ApplicationFrameHost_mCEHzJq5dL](https://github.com/user-attachments/assets/91f14060-aa11-4694-8709-c1a576efd1e5)

- 3 Playground equipment. They are from vanilla game, fixed the economic value to something useful.

![ApplicationFrameHost_1UMGKYwlqg](https://github.com/user-attachments/assets/a0117975-3822-4b29-b574-7db46ef2c131)

- 4 Hanging plants (2 ivys, 1 moss and 1 cobweb). They are from vanilla game, removed the economic value and now they are not sellable to trader.

![image](https://github.com/user-attachments/assets/5086c8c0-f6ff-47fa-9ab8-f8b580ca6d49)

- 3 Satellite dishes. They are from vanilla game.

![ApplicationFrameHost_3H3MIx79Zt](https://github.com/user-attachments/assets/f6045acf-2764-4fac-971e-b690ad97e31a)

- 8 gravestones. They are from vanilla game, removed the economic value and now they are not sellable to trader.

![ApplicationFrameHost_n5IwO3eef5](https://github.com/user-attachments/assets/ab99ecf7-c427-418d-87cb-251c4ecbe786)


  
# Disclaimer

This mod has been created specifically for "Mundo Muerto" server. So their content could be biased by their community. Feel free to suggest new ideas and content but be understanding with it! [Join the server's discord](https://discord.com/invite/brMATqS2sK) and enjoy this and other mods!
